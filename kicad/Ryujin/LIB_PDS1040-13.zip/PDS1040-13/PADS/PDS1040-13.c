*PADS-LIBRARY-SCH-DECALS-V9*

PDS1040-13_2     20    960   97 10 97 10 4 6 0 3 8
TIMESTAMP 2024.07.26.09.10.55
"Default Font"
"Default Font"
660   30    0 1 97 10 "Default Font"
REF-DES
660   -70   0 1 97 10 "Default Font"
PART-TYPE
1040  -240  0 1 97 10 "Default Font"
*
1040  -340  0 1 97 10 "Default Font"
*
CLOSED 4 10 0 -1
1120  20   
920   -80  
920   120  
1120  20   
OPEN   2 10 0 -1
1120  120  
1120  -80  
OPEN   2 10 0 -1
920   20   
670   20   
OPEN   2 10 0 -1
1370  20   
1120  20   
OPEN   3 10 0 -1
670   20   
670   180  
0     180  
OPEN   3 10 0 -1
670   20   
670   -140 
0     -140 
T-200  180   0 0 140   20    0 2 230   0     0 16 PIN
P-520  0     0 2 -80   0     0 2 0
T-200  -140  0 0 140   20    0 2 230   0     0 16 PIN
P-520  0     0 2 -80   0     0 2 0
T1570  20    0 2 140   20    0 2 230   0     0 16 PIN
P-520  0     0 2 -80   0     0 2 0

*END*
